unidecode
=========

Unicode transliterator in Golang - Replaces non-ASCII characters with their ASCII approximations.

Please, use the following import path to ensure a stable API:

```go
    import "gopkgs.com/unidecode.v1"
```

View other available versions, documentation and examples at http://gopkgs.com/unidecode
