// Package pool provides a sync.Pool compatibility layer, which
// falls back to a channel based pool on Go < 1.3.
package pool
