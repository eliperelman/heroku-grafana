pool
====

sync.Pool compatibility layer for for Go - falls back to a channel based pool in Go &lt; 1.3


Please, use the following import path to ensure a stable API:

```go
    import "gopkgs.com/pool.v1"
```

View other available versions, documentation and examples at http://gopkgs.com/pool
